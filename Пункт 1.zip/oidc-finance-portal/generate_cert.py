from OpenSSL import crypto

# Создание ключа
key = crypto.PKey()
key.generate_key(crypto.TYPE_RSA, 4096)

# Создание сертификата
cert = crypto.X509()

cert.get_subject().C = "NL"
cert.get_subject().ST = "North Holland"
cert.get_subject().L = "Amsterdam"
cert.get_subject().O = "Finance Portal"
cert.get_subject().OU = "Security"
cert.get_subject().CN = "localhost"

cert.set_serial_number(1000)
cert.gmtime_adj_notBefore(0)
cert.gmtime_adj_notAfter(365 * 24 * 60 * 60)

cert.set_issuer(cert.get_subject())
cert.set_pubkey(key)

cert.sign(key, "sha256")

# Сохранение сертификата
with open("cert.pem", "wb") as cert_file:
    cert_file.write(
        crypto.dump_certificate(
            crypto.FILETYPE_PEM,
            cert
        )
    )

# Сохранение ключа
with open("key.pem", "wb") as key_file:
    key_file.write(
        crypto.dump_privatekey(
            crypto.FILETYPE_PEM,
            key
        )
    )

print("cert.pem and key.pem generated")