import os

from flask import (
    Flask,
    redirect,
    url_for,
    session,
    render_template,
    request
)

from authlib.integrations.flask_client import OAuth
from authlib.integrations.requests_client import OAuth2Session

from dotenv import load_dotenv

import jwt

# =========================
# Load environment variables
# =========================

load_dotenv()

# =========================
# Flask app
# =========================

app = Flask(__name__)

app.secret_key = os.getenv("SECRET_KEY")

# =========================
# OAuth / OpenID Connect
# =========================

oauth = OAuth(app)

oidc = oauth.register(
    name="oidc",

    client_id=os.getenv("OIDC_CLIENT_ID"),
    client_secret=os.getenv("OIDC_CLIENT_SECRET"),

    server_metadata_url=os.getenv(
        "OIDC_DISCOVERY_URL"
    ),

    client_kwargs={
        "scope": "openid profile email"
    }
)

# =========================
# Home page
# =========================

@app.route("/")
def home():

    return render_template(
        "index.html",
        user=session.get("user")
    )

# =========================
# Login
# Authorization Code Flow
# =========================

@app.route("/login")
def login():

    redirect_uri = url_for(
        "callback",
        _external=True,
        _scheme="https"
    )

    return oidc.authorize_redirect(
        redirect_uri
    )

# =========================
# Callback
# =========================

@app.route("/callback")
def callback():

    # Получаем metadata OIDC provider
    metadata = oidc.load_server_metadata()

    # Создаем OAuth session
    oauth_session = OAuth2Session(
        client_id=os.getenv("OIDC_CLIENT_ID"),
        client_secret=os.getenv("OIDC_CLIENT_SECRET")
    )

    # Обмениваем authorization code на token
    redirect_uri = url_for(
    "callback",
    _external=True,
    _scheme="https"
    )
    token = oauth_session.fetch_token(
        metadata["token_endpoint"],

        authorization_response=request.url,

        redirect_uri=redirect_uri
    )

    # Получаем ID token
    id_token = token["id_token"]

    # Декодируем JWT
    # Для учебного проекта отключаем строгую проверку claims
    decoded = jwt.decode(
        id_token,

        options={
            "verify_signature": False,
            "verify_iat": False,
            "verify_exp": False,
            "verify_nbf": False,
            "verify_aud": False
        }
    )

    print("\n=== JWT PAYLOAD ===")
    print(decoded)

    # Сохраняем пользователя в session
    session["user"] = {
        "sub": decoded.get("sub"),
        "email": decoded.get("email"),
        "name": decoded.get("name")
    }

    session["id_token"] = id_token

    return redirect("/")

# =========================
# Protected profile route
# =========================

@app.route("/profile")
def profile():

    if "user" not in session:
        return redirect("/login")

    return session["user"]

# =========================
# Logout
# =========================

@app.route("/logout")
def logout():

    id_token = session.get("id_token")

    session.clear()

    metadata = oidc.load_server_metadata()

    logout_url = metadata.get(
        "end_session_endpoint"
    )

    if logout_url:

        return redirect(
            f"{logout_url}"
            f"?post_logout_redirect_uri=https://localhost:5000"
            f"&id_token_hint={id_token}"
        )

    return redirect("/")

# =========================
# TLS logging
# =========================

@app.before_request
def log_request():

    print(
        f"[TLS REQUEST] "
        f"scheme={request.scheme} "
        f"path={request.path}"
    )

# =========================
# Run HTTPS Flask app
# =========================

if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        port=5000,

        ssl_context=(
            "cert.pem",
            "key.pem"
        ),

        debug=True
    )